import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {EmployeeDto} from '../shared/employee.dto';
import {EmployeeService} from '../shared/employee.service';

@Component({
  selector: 'app-hr-employees',
  templateUrl: './hr-employees.component.html',
  styleUrls: ['./hr-employees.component.scss']
})
export class HrEmployeesComponent implements OnInit {

  employeeFrmGrp: FormGroup;

  employees: EmployeeDto[] = [];

  employeeId: number = null;

  noDataResult: boolean;

  constructor(private fb: FormBuilder,
              private employeeService: EmployeeService) {
  }

  private loadAllEmployees() {
    this.employeeService.getAllEmployees().then((response) => {
      this.employees = response;
    }, (error) => {
      console.error('Error: ' + error.statusText);
      this.employees = [];
      this.noDataResult = true;
    });
  }

  private getEmployeeById(employeeId: number) {
    if (!isNaN(employeeId)) {
      this.employees = [];
      this.employeeService.getEmployeeById(employeeId).then((employee) => {
        this.employees.push(employee);
        this.employeeId = employee.id;
      }, (error) => {
        console.error('Error: ' + error.statusText);
        this.noDataResult = true;
      });
    }
  }

  ngOnInit() {
    this.employeeFrmGrp = this.fb.group({
      employeeIdCtrl: new FormControl('', [Validators.pattern('[0-9]{1,5}')])
    });
  }

  get hasEmployees() {
    return this.employees && this.employees.length > 0;
  }

  get employeeFound() {
    return this.employeeId != null;
  }

  get employeeIdCtrl() {
    return this.employeeFrmGrp.get('employeeIdCtrl');
  }

  onLoadEmployees = () => {
    console.log('Form submit success!');
    const employeeId = this.employeeIdCtrl.value;
    if (employeeId) {
      this.getEmployeeById(employeeId);
    } else {
      this.loadAllEmployees();
    }
  }
}

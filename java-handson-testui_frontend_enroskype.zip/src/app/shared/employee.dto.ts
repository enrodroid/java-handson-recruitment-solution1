export interface EmployeeDto {
  id: number;
  name: string;
  contract: {
    annualSalary: number
  };
}

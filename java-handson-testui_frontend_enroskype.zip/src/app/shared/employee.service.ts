import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {EmployeeDto} from './employee.dto';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private API_URL = 'http://localhost:8080/hr-api/employees/';

  constructor(private http: HttpClient) {
  }

  public getEmployeeById = (employeeId: number): Promise<EmployeeDto> => {
    return new Promise<EmployeeDto>((resolve, reject) => {
      this.http.get(this.API_URL + employeeId)
        .toPromise()
        .then(response => {
          console.log('Request success! ', response);
          resolve(response as EmployeeDto);
        }, rejectedReason => {
          console.warn('The request fail! ', rejectedReason);
          reject(rejectedReason);
        })
        .catch(error => {
          console.error('The request fail! ', error);
          reject(error);
        });
    });
  }

  public getAllEmployees = (): Promise<EmployeeDto[]> => {
    return new Promise<EmployeeDto[]>((resolve, reject) => {
      this.http.get(this.API_URL)
        .toPromise()
        .then(response => {
          resolve(response as EmployeeDto[]);
        }, rejectedReason => {
          reject(rejectedReason);
        })
        .catch(error => {
          reject(error);
        });
    });
  }
}
